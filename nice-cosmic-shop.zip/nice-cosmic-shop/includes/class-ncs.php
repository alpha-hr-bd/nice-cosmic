<?php
if (!defined('ABSPATH')) exit;

class NCS {
 private static $i;
 private $p,$s,$e;

 public static function instance(){ return self::$i ?: self::$i=new self(); }

 private function __construct(){
  global $wpdb;
  $this->p=$wpdb->prefix.'ncs_products';
  $this->s=$wpdb->prefix.'ncs_sales';
  $this->e=$wpdb->prefix.'ncs_expenses';
  register_activation_hook(dirname(__DIR__).'/nice-cosmic-shop.php',[$this,'activate']);
  add_action('admin_menu',[$this,'menu']);
  add_action('admin_enqueue_scripts',[$this,'assets']);
  add_action('admin_post_ncs_add_product',[$this,'add_product']);
  add_action('admin_post_ncs_sell',[$this,'sell']);
  add_action('admin_post_ncs_expense',[$this,'expense']);
  add_action('admin_post_ncs_delete_product',[$this,'delete_product']);
  add_action('admin_post_ncs_report',[$this,'report']);
 }

 public function activate(){
  global $wpdb;
  require_once ABSPATH.'wp-admin/includes/upgrade.php';
  $c=$wpdb->get_charset_collate();

  dbDelta("CREATE TABLE {$this->p} (
   id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
   name VARCHAR(255) NOT NULL,
   quantity INT NOT NULL DEFAULT 0,
   buy_price DECIMAL(12,2) NOT NULL DEFAULT 0,
   sell_price DECIMAL(12,2) NOT NULL DEFAULT 0,
   min_sell_price DECIMAL(12,2) NOT NULL DEFAULT 0,
   max_sell_price DECIMAL(12,2) NOT NULL DEFAULT 0,
   created_at DATETIME NOT NULL,
   PRIMARY KEY(id)
  ) $c;");

  dbDelta("CREATE TABLE {$this->s} (
   id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
   product_id BIGINT UNSIGNED NOT NULL,
   product_name VARCHAR(255) NOT NULL,
   quantity INT NOT NULL,
   buy_price DECIMAL(12,2) NOT NULL,
   sell_price DECIMAL(12,2) NOT NULL,
   revenue DECIMAL(12,2) NOT NULL,
   cost DECIMAL(12,2) NOT NULL,
   profit DECIMAL(12,2) NOT NULL,
   sold_at DATETIME NOT NULL,
   PRIMARY KEY(id), KEY sold_at(sold_at)
  ) $c;");

  dbDelta("CREATE TABLE {$this->e} (
   id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
   title VARCHAR(255) NOT NULL,
   amount DECIMAL(12,2) NOT NULL,
   expense_date DATETIME NOT NULL,
   PRIMARY KEY(id), KEY expense_date(expense_date)
  ) $c;");
 }

 public function assets($hook){
  if($hook==='toplevel_page_ncs-dashboard')
   wp_enqueue_style('ncs',NCS_URL.'assets/css/admin.css',[],NCS_VERSION);
 }

 public function menu(){
  add_menu_page('Nice Cosmic Shop','Nice Cosmic Shop','manage_options',
   'ncs-dashboard',[$this,'dashboard'],'dashicons-store',25);
 }

 private function money($n){ return '৳'.number_format((float)$n,2); }

 private function totals($from,$to){
  global $wpdb;
  $s=$wpdb->get_row($wpdb->prepare(
   "SELECT COALESCE(SUM(revenue),0) revenue,
           COALESCE(SUM(cost),0) cost,
           COALESCE(SUM(profit),0) profit,
           COALESCE(SUM(quantity),0) qty
    FROM {$this->s} WHERE sold_at BETWEEN %s AND %s",
   $from.' 00:00:00',$to.' 23:59:59'
  ));
  $e=$wpdb->get_var($wpdb->prepare(
   "SELECT COALESCE(SUM(amount),0) FROM {$this->e}
    WHERE expense_date BETWEEN %s AND %s",
   $from.' 00:00:00',$to.' 23:59:59'
  ));
  return [
   'sales'=>(float)$s->revenue,'cost'=>(float)$s->cost,
   'gross'=>(float)$s->profit,'expense'=>(float)$e,
   'net'=>(float)$s->profit-(float)$e,'qty'=>(int)$s->qty
  ];
 }

 public function dashboard(){
  if(!current_user_can('manage_options')) wp_die('Access denied.');
  global $wpdb;
  $today=current_time('Y-m-d');
  $t=$this->totals($today,$today);
  $products=$wpdb->get_results("SELECT * FROM {$this->p} ORDER BY id DESC");
  $sales=$wpdb->get_results("SELECT * FROM {$this->s} ORDER BY id DESC LIMIT 20");
  ?>
  <div class="wrap ncs">
  <h1>🛍️ Nice Cosmic Shop</h1>

  <div class="cards">
   <div>Today's Sales<b><?php echo esc_html($this->money($t['sales'])); ?></b></div>
   <div>Product Cost<b><?php echo esc_html($this->money($t['cost'])); ?></b></div>
   <div>Expense<b><?php echo esc_html($this->money($t['expense'])); ?></b></div>
   <div>Net Profit/Loss<b><?php echo esc_html($this->money($t['net'])); ?></b></div>
  </div>

  <div class="grid">
  <section class="panel"><h2>➕ Add Product</h2>
  <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="form">
   <input type="hidden" name="action" value="ncs_add_product"><?php wp_nonce_field('ncs_add_product'); ?>
   <input name="name" placeholder="Product name" required>
   <input name="quantity" type="number" min="0" placeholder="Quantity" required>
   <input name="buy_price" type="number" step=".01" min="0" placeholder="Buy price" required>
   <input name="sell_price" type="number" step=".01" min="0" placeholder="Sell price" required>
   <input name="min_sell_price" type="number" step=".01" min="0" placeholder="Min sell">
   <input name="max_sell_price" type="number" step=".01" min="0" placeholder="Max sell">
   <button class="primary">Add Product</button>
  </form></section>

  <section class="panel"><h2>🛒 Sell</h2>
  <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="form">
   <input type="hidden" name="action" value="ncs_sell"><?php wp_nonce_field('ncs_sell'); ?>
   <select name="product_id" required><option value="">Select product</option>
   <?php foreach($products as $p): ?>
   <option value="<?php echo (int)$p->id; ?>"><?php echo esc_html($p->name); ?> — Stock <?php echo (int)$p->quantity; ?></option>
   <?php endforeach; ?></select>
   <input name="quantity" type="number" min="1" placeholder="Quantity" required>
   <input name="sell_price" type="number" step=".01" min="0" placeholder="Actual sell price (optional)">
   <button class="primary">Sell</button>
  </form></section>

  <section class="panel"><h2>💸 Expense</h2>
  <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="form">
   <input type="hidden" name="action" value="ncs_expense"><?php wp_nonce_field('ncs_expense'); ?>
   <input name="title" placeholder="Expense name" required>
   <input name="amount" type="number" step=".01" min="0" placeholder="Amount" required>
   <button>Add Expense</button>
  </form></section>
  </div>

  <section class="panel"><h2>📦 Stock</h2>
  <table class="widefat striped"><thead><tr>
   <th>Product</th><th>Stock</th><th>Buy</th><th>Sell</th><th>Min</th><th>Max</th><th></th>
  </tr></thead><tbody>
  <?php foreach($products as $p): ?>
   <tr>
    <td><?php echo esc_html($p->name); ?></td><td><?php echo (int)$p->quantity; ?></td>
    <td><?php echo esc_html($this->money($p->buy_price)); ?></td>
    <td><?php echo esc_html($this->money($p->sell_price)); ?></td>
    <td><?php echo esc_html($this->money($p->min_sell_price)); ?></td>
    <td><?php echo esc_html($this->money($p->max_sell_price)); ?></td>
    <td><a class="button" href="<?php echo esc_url(wp_nonce_url(
      admin_url('admin-post.php?action=ncs_delete_product&id='.$p->id),
      'ncs_delete_product_'.$p->id)); ?>">Delete</a></td>
   </tr>
  <?php endforeach; ?>
  </tbody></table></section>

  <section class="panel"><h2>📜 Recent Sales</h2>
  <table class="widefat striped"><thead><tr>
   <th>Product</th><th>Qty</th><th>Revenue</th><th>Profit</th><th>Date</th>
  </tr></thead><tbody>
  <?php foreach($sales as $s): ?>
   <tr><td><?php echo esc_html($s->product_name); ?></td>
   <td><?php echo (int)$s->quantity; ?></td>
   <td><?php echo esc_html($this->money($s->revenue)); ?></td>
   <td><?php echo esc_html($this->money($s->profit)); ?></td>
   <td><?php echo esc_html($s->sold_at); ?></td></tr>
  <?php endforeach; ?>
  </tbody></table></section>

  <section class="panel"><h2>📄 Reports</h2>
   <a class="button primary" target="_blank" href="<?php echo esc_url(wp_nonce_url(
    admin_url('admin-post.php?action=ncs_report&period=today'),'ncs_report')); ?>">Today PDF</a>
   <a class="button primary" target="_blank" href="<?php echo esc_url(wp_nonce_url(
    admin_url('admin-post.php?action=ncs_report&period=month'),'ncs_report')); ?>">This Month PDF</a>
   <a class="button primary" target="_blank" href="<?php echo esc_url(wp_nonce_url(
    admin_url('admin-post.php?action=ncs_report&period=year'),'ncs_report')); ?>">This Year PDF</a>
  </section>
  </div>
  <?php
 }

 public function add_product(){
  if(!current_user_can('manage_options')||!check_admin_referer('ncs_add_product')) wp_die('Access denied.');
  global $wpdb;
  $wpdb->insert($this->p,[
   'name'=>sanitize_text_field($_POST['name']),
   'quantity'=>max(0,(int)$_POST['quantity']),
   'buy_price'=>max(0,(float)$_POST['buy_price']),
   'sell_price'=>max(0,(float)$_POST['sell_price']),
   'min_sell_price'=>max(0,(float)$_POST['min_sell_price']),
   'max_sell_price'=>max(0,(float)$_POST['max_sell_price']),
   'created_at'=>current_time('mysql')
  ]);
  wp_safe_redirect(admin_url('admin.php?page=ncs-dashboard'));exit;
 }

 public function sell(){
  if(!current_user_can('manage_options')||!check_admin_referer('ncs_sell')) wp_die('Access denied.');
  global $wpdb;
  $id=(int)$_POST['product_id'];$qty=max(1,(int)$_POST['quantity']);
  $p=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->p} WHERE id=%d",$id));
  if(!$p) wp_die('Product not found.');
  if($qty>$p->quantity) wp_die('Not enough stock.');
  $price=$_POST['sell_price']!==''?(float)$_POST['sell_price']:(float)$p->sell_price;
  if($p->min_sell_price>0&&$price<$p->min_sell_price) wp_die('Below minimum sell price.');
  if($p->max_sell_price>0&&$price>$p->max_sell_price) wp_die('Above maximum sell price.');
  $revenue=$price*$qty;$cost=(float)$p->buy_price*$qty;
  $wpdb->update($this->p,['quantity'=>(int)$p->quantity-$qty],['id'=>$id]);
  $wpdb->insert($this->s,[
   'product_id'=>$id,'product_name'=>$p->name,'quantity'=>$qty,
   'buy_price'=>$p->buy_price,'sell_price'=>$price,'revenue'=>$revenue,
   'cost'=>$cost,'profit'=>$revenue-$cost,'sold_at'=>current_time('mysql')
  ]);
  wp_safe_redirect(admin_url('admin.php?page=ncs-dashboard'));exit;
 }

 public function expense(){
  if(!current_user_can('manage_options')||!check_admin_referer('ncs_expense')) wp_die('Access denied.');
  global $wpdb;
  $wpdb->insert($this->e,[
   'title'=>sanitize_text_field($_POST['title']),
   'amount'=>max(0,(float)$_POST['amount']),
   'expense_date'=>current_time('mysql')
  ]);
  wp_safe_redirect(admin_url('admin.php?page=ncs-dashboard'));exit;
 }

 public function delete_product(){
  $id=(int)$_GET['id'];
  if(!current_user_can('manage_options')||!check_admin_referer('ncs_delete_product_'.$id)) wp_die('Access denied.');
  global $wpdb;$wpdb->delete($this->p,['id'=>$id]);
  wp_safe_redirect(admin_url('admin.php?page=ncs-dashboard'));exit;
 }

 public function report(){
  if(!current_user_can('manage_options')||!check_admin_referer('ncs_report')) wp_die('Access denied.');
  $period=sanitize_key($_GET['period']??'today');$today=current_time('Y-m-d');
  if($period==='month'){$from=date('Y-m-01',current_time('timestamp'));$title='Monthly Report';}
  elseif($period==='year'){$from=date('Y-01-01',current_time('timestamp'));$title='Yearly Report';}
  else{$from=$today;$title='Daily Report';}
  $t=$this->totals($from,$today);
  ?>
  <!doctype html><html><head><meta charset="utf-8"><title><?php echo esc_html($title); ?></title>
  <style>
  body{font-family:Arial;max-width:850px;margin:30px auto;padding:20px}
  h1{text-align:center}.box{border:1px solid #ddd;padding:25px;border-radius:15px}
  table{width:100%;border-collapse:collapse}td,th{padding:12px;border-bottom:1px solid #ddd;text-align:left}
  .total{font-size:21px;font-weight:bold}.print{padding:10px 16px}
  @media print{.print{display:none}}
  </style></head><body>
  <button class="print" onclick="window.print()">🖨️ Print / Save as PDF</button>
  <h1>Nice Cosmic Shop</h1>
  <p style="text-align:center"><?php echo esc_html($title); ?> — <?php echo esc_html($from); ?> to <?php echo esc_html($today); ?></p>
  <div class="box"><table>
  <tr><th>Total Sales</th><td><?php echo esc_html($this->money($t['sales'])); ?></td></tr>
  <tr><th>Product Cost</th><td><?php echo esc_html($this->money($t['cost'])); ?></td></tr>
  <tr><th>Gross Profit</th><td><?php echo esc_html($this->money($t['gross'])); ?></td></tr>
  <tr><th>Expenses</th><td><?php echo esc_html($this->money($t['expense'])); ?></td></tr>
  <tr class="total"><th>NET PROFIT / LOSS</th><td><?php echo esc_html($this->money($t['net'])); ?></td></tr>
  <tr><th>Items Sold</th><td><?php echo number_format($t['qty']); ?></td></tr>
  </table></div></body></html>
  <?php exit;
 }
}
