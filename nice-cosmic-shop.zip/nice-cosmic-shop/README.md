# Nice Cosmic Shop

Real MySQL-backed WordPress shop manager.

Features:
- Product stock
- Buy price / sell price / minimum / maximum sell price
- Sell quantity automatically reduces stock
- Automatic revenue, product cost and profit
- Expenses and net profit/loss
- Recent sales history
- Daily / monthly / yearly print-ready reports
- Data is stored in WordPress MySQL tables

Install:
WordPress Dashboard -> Plugins -> Add New -> Upload Plugin -> upload the ZIP -> Activate.

GitHub:
Upload the `nice-cosmic-shop` folder to your GitHub repository.
