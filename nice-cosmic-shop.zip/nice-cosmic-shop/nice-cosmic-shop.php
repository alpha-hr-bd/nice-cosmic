<?php
/**
 * Plugin Name: Nice Cosmic Shop
 * Description: Real MySQL-backed stock, sales, expenses and profit/loss manager.
 * Version: 1.0.0
 * Author: Nice Cosmic Shop
 */
if (!defined('ABSPATH')) exit;
define('NCS_VERSION','1.0.0');
define('NCS_DIR',plugin_dir_path(__FILE__));
define('NCS_URL',plugin_dir_url(__FILE__));
require_once NCS_DIR.'includes/class-ncs.php';
NCS::instance();
